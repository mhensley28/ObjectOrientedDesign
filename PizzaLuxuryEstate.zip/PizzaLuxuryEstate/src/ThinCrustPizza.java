
public class ThinCrustPizza extends Pizza{
	public ThinCrustPizza() {
		description = "Thin Crust Pizza";
	}
 
	public double cost() {
		return 7.00;
	} 
}
