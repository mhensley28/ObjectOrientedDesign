
public class PanPizza extends Pizza{
	public PanPizza() {
		description = "Pan Pizza";
	}
	
	public double cost() {
		return 8.00;
	}
}
