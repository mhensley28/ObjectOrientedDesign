
public class HandTossedPizza extends Pizza{
	public HandTossedPizza() {
		description = "Hand Tossed Pizza";
	}
	
	public double cost() {
		return 7.50;
	}
}
